package lab.crazyspark.aml;

import java.util.Map;

public class MapUtil {

	public static boolean isNotEmpty(Map<String, String> map) {
		return false;
	}
}