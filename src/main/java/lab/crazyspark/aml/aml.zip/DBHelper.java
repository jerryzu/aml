package lab.crazyspark.aml;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.dbutils.QueryRunner;

public class DBHelper {
    private static final BasicDataSource ds = new BasicDataSource();
    private static final QueryRunner runner = new QueryRunner(ds);

    static {
        // ds.setDriverClassName(ConfigHelper.getProperty("jdbc.driver"));
        // ds.setUrl(ConfigHelper.getProperty("jdbc.url"));
        // ds.setUsername(ConfigHelper.getProperty("jdbc.username"));
        // ds.setPassword(ConfigHelper.getProperty("jdbc.password"));
        // ds.setMaxActive(Integer.parseInt(ConfigHelper.getProperty("jdbc.max.active")));
    }

    // 获取数据源
    public static DataSource getDataSource() {
        return ds;
    }

    // 执行查询语句（返回一个对象）
    public static <T> T queryBean(Class<T> cls, String sql, Object... params) {
        Map<String, String> map = EntityHelper.getEntityMap().get(cls);
        return DBUtil.queryBean(runner, cls, map, sql, params);
    }

    // 执行查询语句（返回多个对象）
    public static <T> List<T> queryBeanList(Class<T> cls, String sql, Object... params) {
        Map<String, String> map = EntityHelper.getEntityMap().get(cls);
        return DBUtil.queryBeanList(runner, cls, map, sql, params);
    }

    // 执行更新语句（包括 UPDATE、INSERT、DELETE）
    public static int update(String sql, Object... params) {
        return DBUtil.update(runner, sql, params);
    }
}