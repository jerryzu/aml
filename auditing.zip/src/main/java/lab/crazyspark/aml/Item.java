package lab.crazyspark.aml;

public class Item {
    private Integer n_seq;
    private String c_cde;
    private String c_cnm;
    private String c_par_cde;
    private String c_par_cnm;
    private String c_grp_mrk;

    public Integer getN_seq() {
        return n_seq;
    }

    public void setN_seq(Integer n_seq) {
        this.n_seq = n_seq;
    }

    public String getC_cde() {
        return c_cde;
    }

    public void setC_cde(String c_cde) {
        this.c_cde = c_cde;
    }

    public String getC_cnm() {
        return c_cnm;
    }

    public void setC_cnm(String c_cnm) {
        this.c_cnm = c_cnm;
    }

    public String getC_par_cde() {
        return c_par_cde;
    }

    public void setC_par_cde(String c_par_cde) {
        this.c_par_cde = c_par_cde;
    }

    public String getC_par_cnm() {
        return c_par_cnm;
    }

    public void setC_par_cnm(String c_par_cnm) {
        this.c_par_cnm = c_par_cnm;
    }

    public String getC_grp_mrk() {
        return c_grp_mrk;
    }

    public void setC_grp_mrk(String c_grp_mrk) {
        this.c_grp_mrk = c_grp_mrk;
    }
}